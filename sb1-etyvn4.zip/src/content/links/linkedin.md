---
title: LinkedIn
href: https://linkedin.com/in/oscarillescas
order: 2
icon: fa-linkedin
---